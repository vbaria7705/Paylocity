List of items implemented/used in the solution:
- Chain of responsibility (Design Pattern) 
- Creation and handling of Custom Exception 
- Middleware to handle exceptions at application level
- Factory pattern for creation of respective benefit deduction calculator
- Loosely coupled classes with flexible design and architecture for adding/removing more deduction(s) in future
- Static data and in-memory database as data source for simplicity and ease of testing