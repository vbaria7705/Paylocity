﻿using Api.Calculators;
using Api.Constants;

namespace Api.Factories
{
    public class CalculatorFactory: ICalculatorFactory
    {
        public ICalculator GetCalculator(string deductionCode)
        {
            switch (deductionCode.ToUpper()) {
                case DeductionCode.BaseDeduction:
                    return new BaseDeductionCalculator();
                case DeductionCode.DependentDeduction:
                    return new DependentDeductionCalculator();
                case DeductionCode.HighEarnerDeduction:
                    return new ThresholdDeductionCalculator();
                case DeductionCode.SeniorBenefitDeduction:
                    return new SeniorDeductionCalculator();
                default:
                    throw new NotImplementedException();
            }
        }
    }
}
