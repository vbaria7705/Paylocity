﻿using Api.Calculators;

namespace Api.Factories
{
    public interface ICalculatorFactory
    {
        ICalculator GetCalculator(string deductionCode);
    }
}
