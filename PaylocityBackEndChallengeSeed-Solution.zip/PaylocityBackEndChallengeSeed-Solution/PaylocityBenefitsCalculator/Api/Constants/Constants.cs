﻿namespace Api.Constants
{
    public static class DeductionCode
    {
        public const string BaseDeduction = "BASE";
        public const string DependentDeduction = "DDC";
        public const string HighEarnerDeduction = "HEDC";
        public const string SeniorBenefitDeduction = "SBDC";
    }
}
