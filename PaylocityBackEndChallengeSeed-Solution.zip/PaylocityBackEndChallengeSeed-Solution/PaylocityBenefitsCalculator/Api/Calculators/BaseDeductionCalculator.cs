﻿using Api.Constants;
using Api.Data;
using Api.Dtos;
using Api.Models;

namespace Api.Calculators
{
    public class BaseDeductionCalculator : ICalculator
    {
        private decimal MONTHLY_DEDUCTION_COST = 1000;
        public DeductionDto CalculateDeduction(Employee employee)
        {
            var yearlyDeductionAmount = MONTHLY_DEDUCTION_COST * 12;
            var perPayPeriodAmount = yearlyDeductionAmount / (decimal)26;
            var applicableDeduction = Lookup.GetDeductionCodes().First(d => d.Code == DeductionCode.BaseDeduction);
            return new DeductionDto
            {
                Amount = perPayPeriodAmount,
                DeductionCode = applicableDeduction.Code,
                Description = applicableDeduction.Description
            };
        }

        public bool IsApplicable(Employee employee)
        {
            if (employee == null)
                return false;
            return true;
        }
    }
}
