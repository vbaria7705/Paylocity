﻿using Api.Constants;
using Api.Data;
using Api.Dtos;
using Api.Models;

namespace Api.Calculators
{
    public class ThresholdDeductionCalculator : ICalculator
    {
        private decimal PERCENTAGE_DEDUCTION_COST = 2;
        private decimal THRESHOLD_LIMIT = 80000;        
        public DeductionDto CalculateDeduction(Employee employee)
        {
            var yearlyDeductionAmount = (employee.Salary * PERCENTAGE_DEDUCTION_COST)/ (decimal) 100;
            var perPayPeriodAmount = yearlyDeductionAmount / (decimal)26;
            var applicableDeduction = Lookup.GetDeductionCodes().First(d => d.Code == DeductionCode.HighEarnerDeduction);
            return new DeductionDto
            {
                Amount = perPayPeriodAmount,
                DeductionCode = applicableDeduction.Code,
                Description = applicableDeduction.Description
            };
        }

        public bool IsApplicable(Employee employee)
        {
            if (employee == null)
                return false;
            return employee.Salary > THRESHOLD_LIMIT;
        }
    }
}
