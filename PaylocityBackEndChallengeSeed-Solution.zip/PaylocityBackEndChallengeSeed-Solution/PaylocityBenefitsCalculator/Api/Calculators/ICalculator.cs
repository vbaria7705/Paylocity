﻿using Api.Dtos;
using Api.Models;

namespace Api.Calculators
{
    public interface ICalculator
    {
        public bool IsApplicable(Employee employee);
        public DeductionDto CalculateDeduction(Employee employee);
    }
}
