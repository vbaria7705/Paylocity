using Microsoft.OpenApi.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Api.Engines;
using Api.Calculators;
using Api.Factories;
using Api.Data.QueryProvider;
using Api.Data.Repositories;
using Api.Middlewares;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.EnableAnnotations();
    c.SwaggerDoc("v1", new OpenApiInfo
    {
        Version = "v1",
        Title = "Employee Benefit Cost Calculation Api",
        Description = "Api to support employee benefit cost calculations"
    });
});

//note: when integrating with real sql server using connectionstring
//var connectionString = builder.Configuration.GetConnectionString("ApplicationDbContext");
//builder.Services.AddDbContext<ApplicationDbContext>(options =>
//    options.UseSqlServer(connectionString));


var allowLocalhost = "allow localhost";
builder.Services.AddCors(options =>
{
    options.AddPolicy(allowLocalhost,
        policy => { policy.WithOrigins("http://localhost:3000", "http://localhost"); });
});

builder.Services.AddScoped<IEmployeeRepository, EmployeeRepository>();
builder.Services.AddTransient<IEmployeeQueryProvider, EmployeeQueryProvider>();
builder.Services.AddScoped<IDependentRepository, DependentRepository>();
builder.Services.AddTransient<IDependentQueryProvider, DependentQueryProvider>();
builder.Services.AddTransient<IEmployeePayCheckEngine, EmployeePayCheckEngine>();
builder.Services.AddTransient<ICalculatorFactory, CalculatorFactory>();


var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}
app.UseMiddleware<BaseExceptionHandlerMiddleware>();
app.UseCors(allowLocalhost);

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
