﻿using Api.Dtos.Dependent;
using Api.Models;
using Microsoft.EntityFrameworkCore;

namespace Api.Data.Repositories
{
    public class DependentRepository : IDependentRepository
    {
        public DependentRepository()
        {
            using (var context = new ApplicationDbContext())
            {
                var dependents = new List<Dependent>
                {
                    new()
                    {
                        Id = 1,
                        FirstName = "Spouse",
                        LastName = "Morant",
                        Relationship = Relationship.Spouse,
                        DateOfBirth = new DateTime(1998, 3, 3)
                    },
                    new()
                    {
                        Id = 2,
                        FirstName = "Child1",
                        LastName = "Morant",
                        Relationship = Relationship.Child,
                        DateOfBirth = new DateTime(2020, 6, 23)
                    },
                    new()
                    {
                        Id = 3,
                        FirstName = "Child2",
                        LastName = "Morant",
                        Relationship = Relationship.Child,
                        DateOfBirth = new DateTime(2021, 5, 18)
                    },
                    new()
                    {
                        Id = 4,
                        FirstName = "DP",
                        LastName = "Jordan",
                        Relationship = Relationship.DomesticPartner,
                        DateOfBirth = new DateTime(1974, 1, 2)
                    }
                };
                if (!context.Dependents.Any())
                    context.Dependents.AddRange(dependents);
                context.SaveChanges();
            }
        }
        public List<Dependent> GetDependents()
        {
            using (var context = new ApplicationDbContext())
            {
                var list = context.Dependents.ToList();
                return list;
            }
        }
    }
}
