﻿using Api.Models;

namespace Api.Data.Repositories
{
    public interface IDependentRepository
    {
        List<Dependent> GetDependents();
    }
}
