﻿using Api.Models;

namespace Api.Data.Repositories
{
    public interface IEmployeeRepository
    {
        public List<Employee> GetEmployees();
    }
}
