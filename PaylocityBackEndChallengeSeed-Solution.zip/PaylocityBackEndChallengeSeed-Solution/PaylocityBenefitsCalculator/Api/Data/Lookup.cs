﻿using Api.Constants;
using Api.Models;

namespace Api.Data
{
    public static class Lookup
    {
        public static List<DeductionCodeLookUp> GetDeductionCodes()
        {
            return new List<DeductionCodeLookUp>()
            {
                new DeductionCodeLookUp
                {
                    Id = 1,
                    Code = DeductionCode.BaseDeduction,
                    Description = "Employee Benefit Base Deduction Cost",
                    SortOrder = 1
                },
                new DeductionCodeLookUp
                {
                    Id = 2,
                    Code = DeductionCode.DependentDeduction,
                    Description = "Dependent(s) Deduction Cost",
                    SortOrder = 2
                },
                new DeductionCodeLookUp
                {
                    Id = 3,
                    Code = DeductionCode.HighEarnerDeduction,
                    Description = "High Earner Deduction Cost",
                    SortOrder = 3
                },
                new DeductionCodeLookUp
                {
                    Id = 4,
                    Code = DeductionCode.SeniorBenefitDeduction,
                    Description = "Senior Benefit Deduction Cost",
                    SortOrder = 4
                }
            };
        }
    }
}
