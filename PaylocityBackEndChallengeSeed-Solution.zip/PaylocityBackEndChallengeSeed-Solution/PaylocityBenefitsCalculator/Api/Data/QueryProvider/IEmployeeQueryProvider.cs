﻿using Api.Dtos.Employee;

namespace Api.Data.QueryProvider
{
    public interface IEmployeeQueryProvider
    {
        Task<GetEmployeeDto> GetEmployeeAsync(int id);
        Task<List<GetEmployeeDto>> GetEmployeesAsync();
        GetEmployeeDto GetEmployee(int id);
        List<GetEmployeeDto> GetEmployees();
    }
}
