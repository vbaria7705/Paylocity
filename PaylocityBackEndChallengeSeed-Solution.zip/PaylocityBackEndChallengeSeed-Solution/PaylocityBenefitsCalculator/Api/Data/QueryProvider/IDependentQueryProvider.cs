﻿using Api.Dtos.Dependent;
using Api.Dtos.Employee;

namespace Api.Data.QueryProvider
{
    public interface IDependentQueryProvider
    {
        Task<GetDependentDto> GetDependentAsync(int id);
        Task<List<GetDependentDto>> GetDependentsAsync();
        GetDependentDto GetDependent(int id);
        List<GetDependentDto> GetDependents();
    }
}
