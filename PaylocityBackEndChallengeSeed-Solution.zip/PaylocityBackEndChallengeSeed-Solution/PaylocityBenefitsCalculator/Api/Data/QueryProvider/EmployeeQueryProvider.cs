﻿using Api.Data.Repositories;
using Api.Dtos.Employee;
using Api.Exceptions;
using Api.Extensions;
using Microsoft.EntityFrameworkCore;

namespace Api.Data.QueryProvider
{
    public class EmployeeQueryProvider : IEmployeeQueryProvider
    {
        private readonly IEmployeeRepository _employeeRepository;
        public EmployeeQueryProvider(IEmployeeRepository employeeRepository) 
        {
            _employeeRepository = employeeRepository;
        }

        public GetEmployeeDto GetEmployee(int id)
        {
            var employee = _employeeRepository.GetEmployees().FirstOrDefault(e => e.Id == id);
            if (employee == null)            
                throw new NotFoundException("Employee not found");
            
            return employee.ToDto();            
        }

        public async Task<GetEmployeeDto> GetEmployeeAsync(int id)
        {
            throw new NotImplementedException();
        }

        public List<GetEmployeeDto> GetEmployees()
        {
            var employees = _employeeRepository.GetEmployees();
            var result = new List<GetEmployeeDto>();
            foreach (var employee in employees)
            {
                result.Add(employee.ToDto());
            }
            return result;
        }

        public async Task<List<GetEmployeeDto>> GetEmployeesAsync()
        {
            throw new NotImplementedException();
        }
    }
}
