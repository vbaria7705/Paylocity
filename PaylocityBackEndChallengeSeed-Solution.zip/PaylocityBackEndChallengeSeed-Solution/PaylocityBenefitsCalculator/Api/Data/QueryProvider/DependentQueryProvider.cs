﻿using Api.Data.Repositories;
using Api.Dtos.Dependent;
using Api.Dtos.Employee;
using Api.Exceptions;
using Api.Extensions;

namespace Api.Data.QueryProvider
{
    public class DependentQueryProvider : IDependentQueryProvider
    {
        private readonly IDependentRepository _dependentRepository;
        public DependentQueryProvider(IDependentRepository dependentRepository)
        {
            _dependentRepository = dependentRepository;
        }

        public GetDependentDto GetDependent(int id)
        {
            var dependent = _dependentRepository.GetDependents().FirstOrDefault(e => e.Id == id);
            if (dependent == null)
                throw new NotFoundException("Dependent not found");

            return dependent.ToDto();
        }

        public List<GetDependentDto> GetDependents()
        {
            var dependents = _dependentRepository.GetDependents();
            var result = new List<GetDependentDto>();
            foreach (var dependent in dependents)
            {
                result.Add(dependent.ToDto());
            }
            return result;
        }

        public Task<GetDependentDto> GetDependentAsync(int id)
        {
            throw new NotImplementedException();
        }        

        public Task<List<GetDependentDto>> GetDependentsAsync()
        {
            throw new NotImplementedException();
        }
    }
}
