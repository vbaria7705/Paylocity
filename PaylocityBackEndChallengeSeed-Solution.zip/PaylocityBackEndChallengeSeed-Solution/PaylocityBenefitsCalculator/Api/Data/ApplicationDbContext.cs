﻿using Api.Models;
using Microsoft.EntityFrameworkCore;

namespace Api.Data
{
    //note: for simplicity purpose we are using in-memory database in entity framework
    //this can be configured to use actual SQL Server/Azure SQL or any other relational database for production application
    public class ApplicationDbContext : DbContext
    {
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseInMemoryDatabase(databaseName: "EmployeePayroll");
        }
        public DbSet<Employee> Employees { get; set ; }
        public DbSet<Dependent> Dependents { get; set; }
        public DbSet<DeductionCodeLookUp> DeductionCodeLookUp { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {           
            modelBuilder.Entity<Employee>()
                .HasMany(e => e.Dependents)
                .WithOne(e => e.Employee)
                .HasForeignKey(e => e.EmployeeId);            
        }
    }
}
