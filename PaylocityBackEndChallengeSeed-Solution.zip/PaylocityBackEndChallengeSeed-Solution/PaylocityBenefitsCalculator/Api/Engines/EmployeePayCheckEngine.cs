﻿using Api.Data;
using Api.Data.QueryProvider;
using Api.Data.Repositories;
using Api.Dtos;
using Api.Exceptions;
using Api.Factories;
using Microsoft.EntityFrameworkCore;

namespace Api.Engines
{
    public class EmployeePayCheckEngine : IEmployeePayCheckEngine
    {
        private readonly IEmployeeRepository _employeeRepository;
        private readonly ICalculatorFactory _calculatorFactory;
        public EmployeePayCheckEngine(IEmployeeRepository employeeRepository, ICalculatorFactory calculatorFactory) 
        {
            _employeeRepository = employeeRepository;
            _calculatorFactory = calculatorFactory;
        }
        public async Task<GetPaycheckDto> GenerateEmployeePaycheck(int employeeId)
        {
            var employee = _employeeRepository.GetEmployees().FirstOrDefault(e => e.Id == employeeId);
            if (employee == null)
                throw new NotFoundException("Employee not found");

            var employeePaycheck = new GetPaycheckDto
            {
                employeeId = employee.Id,
                DateOfBirth = employee.DateOfBirth,
                FirstName = employee.FirstName,
                LastName = employee.LastName,
                GrossSalary = employee.Salary / (decimal)26,
                NetSalary = employee.Salary / (decimal)26
            };

            //note: deduction code can be stored in the database table and retrieve like below for more dynamic approach
            //var availableDeductionCodes = await _applicationContext.DeductionCodeLookUp.ToListAsync();

            //note: for simplicity we will use static lookup values 
            var availableDeductionCodes = Lookup.GetDeductionCodes().OrderBy(o => o.SortOrder);

            foreach (var d in availableDeductionCodes)
            {
                var calculator = _calculatorFactory.GetCalculator(d.Code);
                if (calculator.IsApplicable(employee))
                {
                    var deduction = calculator.CalculateDeduction(employee);
                    employeePaycheck.Deductions.Add(deduction);
                }                    
            }

            foreach(var deduction in employeePaycheck.Deductions)
            {
                employeePaycheck.NetSalary = employeePaycheck.NetSalary - deduction.Amount;
            }

            return employeePaycheck;            
        }
    }
}
