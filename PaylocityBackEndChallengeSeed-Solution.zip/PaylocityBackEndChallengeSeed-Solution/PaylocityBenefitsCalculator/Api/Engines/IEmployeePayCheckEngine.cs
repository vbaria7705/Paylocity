﻿using Api.Dtos;

namespace Api.Engines
{
    public interface IEmployeePayCheckEngine
    {
        public Task<GetPaycheckDto> GenerateEmployeePaycheck(int employeeId);
    }
}
