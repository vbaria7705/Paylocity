namespace Api.Models;

public enum Relationship
{
    None,
    Spouse,
    DomesticPartner,
    Child
}

