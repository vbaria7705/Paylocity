﻿namespace Api.Dtos
{
    public class DeductionDto
    {
        public string DeductionCode { get; set; }
        public string Description { get; set; }
        public decimal Amount { get; set; }
    }
}
