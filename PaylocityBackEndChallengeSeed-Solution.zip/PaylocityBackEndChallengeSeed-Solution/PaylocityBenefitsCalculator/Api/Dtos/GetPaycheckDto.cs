﻿using Api.Dtos.Dependent;

namespace Api.Dtos
{
    public class GetPaycheckDto
    {
        public int employeeId { get; set; }        
        public string? FirstName { get; set; }
        public string? LastName { get; set; }
        public decimal GrossSalary { get; set; }
        public decimal NetSalary { get; set; }
        public DateTime DateOfBirth { get; set; }
        public ICollection<DeductionDto> Deductions { get; set; } = new List<DeductionDto>();

    }
}
