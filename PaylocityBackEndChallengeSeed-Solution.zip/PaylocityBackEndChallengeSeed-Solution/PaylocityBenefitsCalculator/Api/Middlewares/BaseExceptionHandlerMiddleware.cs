﻿using Api.Dtos;
using Api.Exceptions;
using Api.Models;
using Newtonsoft.Json;
using System.Net;
using System.Reflection;

namespace Api.Middlewares
{
    public class BaseExceptionHandlerMiddleware:ExceptionHandlerMiddleware
    {
        private readonly ILogger<BaseExceptionHandlerMiddleware> _logger;
        public BaseExceptionHandlerMiddleware(RequestDelegate next, ILogger<BaseExceptionHandlerMiddleware> logger) : base(next)
        {
            _logger = logger;
        }

        public override (HttpStatusCode code, string message) GetResponse(Exception exception)
        {
            //note: the exception with full stack trace should be logged to telemetry for investigation and tracking
            _logger.LogError(exception, exception.Message);
            HttpStatusCode code;
            switch (exception)
            {               
                case NotFoundException:                  
                    code = HttpStatusCode.NotFound;
                    return (code, JsonConvert.SerializeObject(new ApiResponse<GetPaycheckDto>
                    {
                        Success = false,
                        Error = exception.Message,
                        Message = exception.Message
                    }));                
                default:
                    code = HttpStatusCode.InternalServerError;
                    return (code, JsonConvert.SerializeObject(new ApiResponse<GetPaycheckDto>
                    {
                        Success = false,
                        Error = "Unexpected error occured. Please contact system administrator for help",
                        Message = "Unexpected error occured. Please contact system administrator for help"
                    }));                    
            }            
            
        }
    }
}
