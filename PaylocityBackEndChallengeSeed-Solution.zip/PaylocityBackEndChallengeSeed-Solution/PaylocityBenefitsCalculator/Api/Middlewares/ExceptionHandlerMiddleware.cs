﻿using System.Net;
using Microsoft.Extensions.Logging;

namespace Api.Middlewares
{
    public abstract class ExceptionHandlerMiddleware
    {
        private readonly RequestDelegate _next;        
        public ExceptionHandlerMiddleware(RequestDelegate next) 
        {
            _next = next;           
        }
        public abstract (HttpStatusCode code, string message) GetResponse(Exception exception);
        public async Task Invoke(HttpContext context)
        {
            try
            {
                await _next(context);
            }
            catch (Exception exception)
            {               
                var response = context.Response;
                response.ContentType = "application/json";

                // get the response code and message
                var (status, message) = GetResponse(exception);
                response.StatusCode = (int)status;
                await response.WriteAsync(message);
            }
        }
    }
}
