﻿using Api.Data.QueryProvider;
using Api.Dtos.Dependent;
using Api.Dtos.Employee;
using Api.Exceptions;
using Api.Models;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.Annotations;

namespace Api.Controllers;

[ApiController]
[Route("api/v1/[controller]")]
public class DependentsController : ControllerBase
{
    private readonly IDependentQueryProvider _queryProvider;
    public DependentsController(IDependentQueryProvider queryProvider)
    {
        _queryProvider = queryProvider;
    }

    [SwaggerOperation(Summary = "Get dependent by id")]
    [HttpGet("{id}")]
    public async Task<ActionResult<ApiResponse<GetDependentDto>>> Get(int id)
    {
        //throw new NotImplementedException();
        var dependent = _queryProvider.GetDependent(id);
        var result = new ApiResponse<GetDependentDto>
        {
            Data = dependent,
            Success = true
        };
        return result;
    }

    [SwaggerOperation(Summary = "Get all dependents")]
    [HttpGet("")]
    public async Task<ActionResult<ApiResponse<List<GetDependentDto>>>> GetAll()
    {
        var dependents = _queryProvider.GetDependents();
        var result = new ApiResponse<List<GetDependentDto>>
        {
            Data = dependents,
            Success = true
        };
        return result;
    }
}
