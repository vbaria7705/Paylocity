﻿using Api.Dtos;
using Api.Dtos.Dependent;
using Api.Dtos.Employee;
using Api.Engines;
using Api.Exceptions;
using Api.Models;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.Annotations;

namespace Api.Controllers
{
    [ApiController]
    [Route("api/v1/[controller]")]
    public class PaycheckController: ControllerBase
    {
        private readonly IEmployeePayCheckEngine _engine;
        public PaycheckController(IEmployeePayCheckEngine engine) 
        {
            _engine = engine;
        }

        [SwaggerOperation(Summary = "Get Employee Paycheck by Employee Id")]
        [HttpGet("employee/{id}")]
        public async Task<ActionResult<ApiResponse<GetPaycheckDto>>> Get(int id)
        {
            var employeePayCheck = await _engine.GenerateEmployeePaycheck(id);
            var result = new ApiResponse<GetPaycheckDto>
            {
                Data = employeePayCheck,
                Success = true
            };
            return result;
        }
    }
}
