﻿using Api.Dtos.Dependent;
using Api.Dtos.Employee;
using Api.Models;

namespace Api.Extensions
{
    public static class Extensions
    {
        public static GetEmployeeDto ToDto(this Employee employee)
        {
            var employeeDto = new GetEmployeeDto
            {
                Id = employee.Id,
                DateOfBirth = employee.DateOfBirth,
                FirstName = employee.FirstName,
                LastName = employee.LastName,
                Salary = employee.Salary,
                Dependents = new List<GetDependentDto>()
            };

            foreach (var dependent in employee.Dependents) 
            {
                employeeDto.Dependents.Add(dependent.ToDto());
            }
            return employeeDto;
        }

        public static GetDependentDto ToDto(this Dependent dependent)
        {
            return new GetDependentDto
            {
                Id = dependent.Id,
                FirstName = dependent.FirstName,
                LastName = dependent.LastName,
                DateOfBirth = dependent.DateOfBirth,
                Relationship = dependent.Relationship,
            };
        }

    }
}
