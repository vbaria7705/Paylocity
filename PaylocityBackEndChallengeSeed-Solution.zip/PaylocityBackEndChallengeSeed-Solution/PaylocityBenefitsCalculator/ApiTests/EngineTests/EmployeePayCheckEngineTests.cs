﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Api.Data.Repositories;
using Api.Engines;
using Api.Exceptions;
using Api.Factories;
using Api.Models;
using Moq;
using Xunit;

namespace ApiTests.EngineTests
{
    public class EmployeePayCheckEngineTests
    {
        [Fact]
        public async Task GetPayCheckFor_NonExistingEmployee()
        {
            //arrange
            var mockEmployeeRepository = new Mock<IEmployeeRepository>();
            var employees = new List<Employee>();
            mockEmployeeRepository.Setup(m => m.GetEmployees()).Returns(employees);
            var calculatorFactory = new CalculatorFactory();
            var engine = new EmployeePayCheckEngine(mockEmployeeRepository.Object, calculatorFactory);

            //act & assert
            Assert.ThrowsAsync<NotFoundException>(async () => await engine.GenerateEmployeePaycheck(-100));            
        }

        [Fact]
        public async Task GetPayCheckFor_ExistingEmployee_WithoutAnyDependents()
        {
            //arrange
            var mockEmployeeRepository = new Mock<IEmployeeRepository>();
            var employee = new Employee
            {

                Id = 50,
                FirstName = "Single",
                LastName = "Tester",
                Salary = 24000.00m,
                DateOfBirth = new DateTime(1984, 12, 30)
            };
            var baseDeductionPerPayPeriod = ((decimal)1000*(decimal)12/(decimal)26);
            var perPaycheckSalary = employee.Salary / (decimal)26;
            var employees = new List<Employee>() { employee };
            mockEmployeeRepository.Setup(m => m.GetEmployees()).Returns(employees);
            var calculatorFactory = new CalculatorFactory();
            var engine = new EmployeePayCheckEngine(mockEmployeeRepository.Object, calculatorFactory);

            //act
            var result = await engine.GenerateEmployeePaycheck(50);

            //assert
            Assert.NotNull(result);
            Assert.Equal(employee.Id, result.employeeId);
            Assert.Equal(employee.FirstName, result.FirstName);
            Assert.Equal(employee.LastName, result.LastName);
            Assert.Equal(employee.DateOfBirth, result.DateOfBirth);
            Assert.Equal(perPaycheckSalary, result.GrossSalary);
            Assert.Equal(perPaycheckSalary - baseDeductionPerPayPeriod, result.NetSalary);
        }

        [Fact]
        public async Task GetPayCheckFor_ExistingEmployee_WithPartnerOnly()
        {
            //arrange
            var mockEmployeeRepository = new Mock<IEmployeeRepository>();
            var employee = new Employee
            {
                Id = 50,
                FirstName = "Married",
                LastName = "Tester",
                Salary = 24000.00m,
                DateOfBirth = new DateTime(1984, 12, 30),
                Dependents = new List<Dependent>
                        {
                            new()
                            {
                                Id = 51,
                                FirstName = "Spouse",
                                LastName = "Tester",
                                Relationship = Relationship.DomesticPartner,
                                DateOfBirth = new DateTime(1985, 12, 30)
                            }
                        }
            };
            
            var baseDeductionPerPayPeriod = ((decimal)1000 * (decimal)12 / (decimal)26);
            var dependentDeductionPerPayPeriod = ((decimal)600 * (decimal)12 / (decimal)26);
            var perPaycheckSalary = employee.Salary / (decimal)26;
            var employees = new List<Employee>() { employee };
            mockEmployeeRepository.Setup(m => m.GetEmployees()).Returns(employees);
            var calculatorFactory = new CalculatorFactory();
            var engine = new EmployeePayCheckEngine(mockEmployeeRepository.Object, calculatorFactory);

            //act
            var result = await engine.GenerateEmployeePaycheck(50);

            //assert
            Assert.NotNull(result);
            Assert.Equal(employee.Id, result.employeeId);
            Assert.Equal(employee.FirstName, result.FirstName);
            Assert.Equal(employee.LastName, result.LastName);
            Assert.Equal(employee.DateOfBirth, result.DateOfBirth);
            Assert.Equal(perPaycheckSalary, result.GrossSalary);
            Assert.Equal(perPaycheckSalary - baseDeductionPerPayPeriod - dependentDeductionPerPayPeriod, result.NetSalary);
        }

        [Fact]
        public async Task GetPayCheckFor_ExistingEmployee_WithPartner_AndChild()
        {
            //arrange
            var mockEmployeeRepository = new Mock<IEmployeeRepository>();
            var employee = new Employee
            {
                Id = 50,
                FirstName = "Married",
                LastName = "Tester",
                Salary = 24000.00m,
                DateOfBirth = new DateTime(1984, 12, 30),
                Dependents = new List<Dependent>
                        {
                            new()
                            {
                                Id = 51,
                                FirstName = "Spouse",
                                LastName = "Tester",
                                Relationship = Relationship.DomesticPartner,
                                DateOfBirth = new DateTime(1985, 12, 30)
                            },                            
                            new()
                            {
                                Id = 52,
                                FirstName = "Child",
                                LastName = "Tester",
                                Relationship = Relationship.Child,
                                DateOfBirth = new DateTime(2010, 01, 01)
                            }                        
                        }
            };

            var baseDeductionPerPayPeriod = ((decimal)1000 * (decimal)12 / (decimal)26);
            var dependentDeductionPerPayPeriod = ((decimal)600 * (decimal)12 / (decimal)26) * employee.Dependents.Count;
            var perPaycheckSalary = employee.Salary / (decimal)26;
            var employees = new List<Employee>() { employee };
            mockEmployeeRepository.Setup(m => m.GetEmployees()).Returns(employees);
            var calculatorFactory = new CalculatorFactory();
            var engine = new EmployeePayCheckEngine(mockEmployeeRepository.Object, calculatorFactory);

            //act
            var result = await engine.GenerateEmployeePaycheck(50);

            //assert
            Assert.NotNull(result);
            Assert.Equal(employee.Id, result.employeeId);
            Assert.Equal(employee.FirstName, result.FirstName);
            Assert.Equal(employee.LastName, result.LastName);
            Assert.Equal(employee.DateOfBirth, result.DateOfBirth);
            Assert.Equal(perPaycheckSalary, result.GrossSalary);
            Assert.Equal(perPaycheckSalary - baseDeductionPerPayPeriod - dependentDeductionPerPayPeriod, result.NetSalary);
        }

        [Fact]
        public async Task GetPayCheckFor_ExistingHigheEarnerEmployee_WithPartner_AndChild()
        {
            //arrange
            var mockEmployeeRepository = new Mock<IEmployeeRepository>();
            var employee = new Employee
            {
                Id = 50,
                FirstName = "Married",
                LastName = "Tester",
                Salary = 100000.00m,
                DateOfBirth = new DateTime(1984, 12, 30),
                Dependents = new List<Dependent>
                        {
                            new()
                            {
                                Id = 51,
                                FirstName = "Spouse",
                                LastName = "Tester",
                                Relationship = Relationship.DomesticPartner,
                                DateOfBirth = new DateTime(1985, 12, 30)
                            },
                            new()
                            {
                                Id = 52,
                                FirstName = "Child",
                                LastName = "Tester",
                                Relationship = Relationship.Child,
                                DateOfBirth = new DateTime(2010, 01, 01)
                            }
                        }
            };

            var baseDeductionPerPayPeriod = ((decimal)1000 * (decimal)12 / (decimal)26);
            var dependentDeductionPerPayPeriod = ((decimal)600 * (decimal)12 / (decimal)26) * employee.Dependents.Count;
            var yearlyHighEarnerDeductionAmount = (employee.Salary * 2) / (decimal)100;
            var yearlyHighEarnerDeductionPerPayPeriod = yearlyHighEarnerDeductionAmount / (decimal)26;
            var perPaycheckSalary = employee.Salary / (decimal)26;
            var employees = new List<Employee>() { employee };
            mockEmployeeRepository.Setup(m => m.GetEmployees()).Returns(employees);
            var calculatorFactory = new CalculatorFactory();
            var engine = new EmployeePayCheckEngine(mockEmployeeRepository.Object, calculatorFactory);

            //act
            var result = await engine.GenerateEmployeePaycheck(50);

            //assert
            Assert.NotNull(result);
            Assert.Equal(employee.Id, result.employeeId);
            Assert.Equal(employee.FirstName, result.FirstName);
            Assert.Equal(employee.LastName, result.LastName);
            Assert.Equal(employee.DateOfBirth, result.DateOfBirth);
            Assert.Equal(perPaycheckSalary, result.GrossSalary);
            Assert.Equal(perPaycheckSalary - baseDeductionPerPayPeriod - dependentDeductionPerPayPeriod - yearlyHighEarnerDeductionPerPayPeriod, result.NetSalary);
        }

        [Fact]
        public async Task GetPayCheckFor_ExistingHigheEarnerSeniorCitizenEmployee_WithPartner_AndChild()
        {
            //arrange
            var mockEmployeeRepository = new Mock<IEmployeeRepository>();
            var employee = new Employee
            {
                Id = 50,
                FirstName = "Married",
                LastName = "Tester",
                Salary = 100000.00m,
                DateOfBirth = new DateTime(1950, 12, 30),
                Dependents = new List<Dependent>
                        {
                            new()
                            {
                                Id = 51,
                                FirstName = "Spouse",
                                LastName = "Tester",
                                Relationship = Relationship.DomesticPartner,
                                DateOfBirth = new DateTime(1951, 12, 30)
                            },
                            new()
                            {
                                Id = 52,
                                FirstName = "Child",
                                LastName = "Tester",
                                Relationship = Relationship.Child,
                                DateOfBirth = new DateTime(1980, 01, 01)
                            }
                        }
            };

            var baseDeductionPerPayPeriod = ((decimal)1000 * (decimal)12 / (decimal)26);
            var dependentDeductionPerPayPeriod = ((decimal)600 * (decimal)12 / (decimal)26) * employee.Dependents.Count;
            var yearlyHighEarnerDeductionAmount = (employee.Salary * 2) / (decimal)100;
            var yearlyHighEarnerDeductionPerPayPeriod = yearlyHighEarnerDeductionAmount / (decimal)26;
            var yearlySeniorBenefitDeductionAmount = 200 * 12;
            var yearlySeniorBenefitDeductionPerPayPeriod = yearlySeniorBenefitDeductionAmount / (decimal)26;
            var perPaycheckSalary = employee.Salary / (decimal)26;
            var employees = new List<Employee>() { employee };
            mockEmployeeRepository.Setup(m => m.GetEmployees()).Returns(employees);
            var calculatorFactory = new CalculatorFactory();
            var engine = new EmployeePayCheckEngine(mockEmployeeRepository.Object, calculatorFactory);

            //act
            var result = await engine.GenerateEmployeePaycheck(50);

            //assert
            Assert.NotNull(result);
            Assert.Equal(employee.Id, result.employeeId);
            Assert.Equal(employee.FirstName, result.FirstName);
            Assert.Equal(employee.LastName, result.LastName);
            Assert.Equal(employee.DateOfBirth, result.DateOfBirth);
            Assert.Equal(perPaycheckSalary, result.GrossSalary);
            Assert.Equal(perPaycheckSalary - baseDeductionPerPayPeriod - dependentDeductionPerPayPeriod - yearlyHighEarnerDeductionPerPayPeriod - yearlySeniorBenefitDeductionPerPayPeriod, result.NetSalary);
        }
    }
}
